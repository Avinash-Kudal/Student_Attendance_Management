from django.contrib import admin

# Register your models here.
from sndstudent.models import students
from sndstudent.models import contact1
# IT'S 7 NO STEP IN THIS WE WRITE REGISTRATION METHOD.

# Register your models here.
admin.site.register(students)
admin.site.register(contact1)