from django.apps import AppConfig


class SndstudentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sndstudent'
