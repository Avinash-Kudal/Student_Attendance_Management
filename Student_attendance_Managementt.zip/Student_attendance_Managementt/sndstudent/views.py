from django.shortcuts import render,redirect
from sndstudent.models import students,contact1
# Create your views here.
def home(r):
    return render(r,'sndstudent/index.html')
def add(request):
    print(request.method)
    if request.method=='POST':
        print(request.POST)
        smail=request.POST.get('eid')
        spass=request.POST.get('ps')
        sad1=request.POST.get('ad1')
        sad2=request.POST.get('ad2')
        scity=request.POST.get('cty')
        sstate=request.POST.get('st')
        szp=request.POST.get('Zp')
        s1=students(s_mail=smail,s_pass=spass,s_adress1=sad1,s_adress2=sad2,s_city=scity,s_state=sstate,s_zip=szp)
        s1.save()
        # return redirect('')
    return render(request,'sndstudent/add.html')
def display(request):
    data= students.objects.all()#it is useed to get all requerd from object.
    context={
        'data':data
    }
    return render(request,'sndstudent/display.html',context)

def contact(request):
    print(request.method)
    if request.method == "POST":
        print(request.POST)        
        name1= request.POST.get('name')
        email1= request.POST.get('email')
        message1= request.POST.get('message')
        s2=contact1(name=name1,email=email1,message=message1)
        s2.save()  
        
    return render(request, 'sndstudent/contact.html')
def update(request,id):
    data= students.objects.get(pk=id)
    if request.method=='POST':
        print(request.POST)
        smail=request.POST.get('eid')
        spass=request.POST.get('ps')
        sad1=request.POST.get('ad1')
        sad2=request.POST.get('ad2')
        scity=request.POST.get('cty')
        sstate=request.POST.get('st')
        szp=request.POST.get('Zp')
        # s1=students(s_mail=smail,s_pass=spass,s_adress1=sad1,s_adress2=sad2,s_city=scity,s_state=sstate,s_zip=szp)
        # s1.save
        data.s_mail=smail
        data.s_pass=spass
        data.s_adress1=sad1
        data.s_adress2=sad2
        data.s_city=scity
        data.s_state=sstate
        data.s_zip=szp     

        data.save()
        return redirect('/display')
    # it is useed to get all requerd from object.
    context={
        'data':data
    }
    return render(request,'sndstudent/update.html',context)




