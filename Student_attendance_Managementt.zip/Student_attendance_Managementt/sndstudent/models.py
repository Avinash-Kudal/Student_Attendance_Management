from django.db import models

# Create your models here.
class students(models.Model):
    s_mail=models.CharField(('zipcode'),max_length=50)
    s_pass=models.CharField(max_length=50)
    s_adress1=models.CharField(max_length=50)
    s_adress2=models.CharField(max_length=50)
    s_city=models.CharField(max_length=50)
    s_state=models.CharField(max_length=50)
    s_zip=models.CharField(max_length=50)

    def __str__(self):
         return self.s_mail

class contact1(models.Model):
    name = models.CharField(max_length=158)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return self.name
